#!/bin/bash
## Just what chmodding to make these python files executable
## if for some reason these files are not executable you can run this script now
chmod u+x ./gmail/gmail.py
chmod u+x ./spotify/spotify_album_cover.sh
chmod u+x ./spotify/spotify_info_album.sh
chmod u+x ./spotify/spotify_info_artist.sh
chmod u+x ./spotify/spotify_info_title.sh
chmod u+x ./transmission/transmission.py
chmod u+x ./transmission/transmission.sh
chmod u+x ./rss/rss.sh
