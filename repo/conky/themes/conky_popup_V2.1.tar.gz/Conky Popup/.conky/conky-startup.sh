#!/bin/bash

killall conky
conky -c ~/.conky/conkyrc_popup ;

exit 0
