#==============================================================================
#                               aurora
# Date    : 26/06/2016
# Author  : Erik Dubois at http://www.erikdubois.be
# Version : v3.0.4
# License : Distributed under the terms of GNU GPL version 2 or later
# Documentation English: http://erikdubois.be/linux/install-conky-theme-aurora
# Documentation Dutch: http://erikdubois.be/linux/conky
#==============================================================================

#Linux Mint Cinnamon seems to work better with this option
sed -i 's/###Loading lua script###/###Loading lua script###/g' *aurora*
