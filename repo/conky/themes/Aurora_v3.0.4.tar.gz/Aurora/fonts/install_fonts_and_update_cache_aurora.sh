sudo cp *.ttf ~/.fonts
fc-cache -fv
